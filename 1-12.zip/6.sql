--6) Os nomes dos eleitores da se��o 40 que n�o votaram em 1998. (0,8)

SELECT NOME
FROM ELEITOR E
WHERE E.SECAO = 40
AND E.TITULO NOT IN 
(
    SELECT E.TITULO
    FROM ELEITOR E, VOTACAO V
    WHERE E.SECAO = 40
    AND E.TITULO = V.ELEITOR
    AND V.ANO = 1998
)
